###################
License and funding
###################

This work was supported by the National Science Foundation through grants 
`SES-1947805 <https://www.nsf.gov/awardsearch/showAward?AWD_ID=1947805>`_ and 
`SES-2019432 <https://www.nsf.gov/awardsearch/showAward?AWD_ID=2019432>`_, 
and by the National Institutes of Health through grant 
`R01 GM072611-16 <https://reporter.nih.gov/project-details/10093056>`_.